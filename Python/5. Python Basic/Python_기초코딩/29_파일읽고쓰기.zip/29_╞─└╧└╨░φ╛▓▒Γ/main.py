
# 문자열 데이터 쓰기
def save_text() :
    # # 파일을 쓰기 위해 열어준다.
    # # 파일이 없으면 생성된다.
    # f1 = open('test1.txt', 'wt', encoding='UTF-8')
    # # 파일을 쓴다.
    # f1.write('문자열1')
    # f1.write('문자열2')
    # f1.write('문자열3')
    # # 파일을 닫아준다.
    # f1.close()

    with open('test2.txt', 'wt', encoding = 'UTF-8') as f2 :
        # f2.write('문자열1\n')
        # f2.write('문자열2\n')
        # f2.write('문자열3\n')
        str_list = ['문자열1\n', '문자열2\n', '문자열3\n']
        f2.writelines(str_list)

    print('저장완료')

def append_text() :
    with open('test2.txt', 'at', encoding='UTF-8') as f3 :
        # f3.write('문자열4\n')
        # f3.write('문자열5\n')
        # f3.write('문자열6\n')
        str_list = ['문자열7\n', '문자열8\n', '문자열9\n']
        f3.writelines(str_list)

    print('추가 완료')

def read_text() :
    with open('test2.txt', 'rt', encoding='UTF-8') as f4 :
        str1 = f4.readline()
        str2 = f4.readline()
        str3 = f4.readline()

        print(str1, end='')
        print(str2, end='')
        print(str3, end='')

        print('-----------------------------')

    with open('test2.txt', 'rt', encoding='UTF-8') as f4 :
        str_lines = f4.readlines()
        print(str_lines)

if __name__ == '__main__' :
    # save_text()
    # append_text()
    read_text()