### sub3.py ###

def sub3_function1() :
    print('main과 같은 패키지의 모듈 sub3 fun1')

def sub3_function2() :
    print('main과 같은 패키지의 모듈 sub3 fun2')
