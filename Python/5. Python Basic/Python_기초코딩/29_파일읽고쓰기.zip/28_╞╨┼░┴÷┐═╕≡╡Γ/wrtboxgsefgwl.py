# wrtboxgsefgwl.py

def wrt_function1() :
    print('main과 같은 패키지의 모듈 wrt fun1')

def wrt_function2() :
    print('main과 같은 패키지의 모듈 wrt fun2')
