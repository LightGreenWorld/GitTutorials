### pkg1_sub1.py ###

def pkg1_sub1_function1() :
    print('pkg1 패키지의 모듈 pkg1_sub1 fun1')

def pkg1_sub1_function2() :
    print('pkg1 패키지의 모듈 pkg1_sub1 fun2')
