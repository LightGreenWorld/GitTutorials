### sub1.py ###

def sub1_function1() :
    print('main과 같은 패키지의 모듈 sub1 fun1')

def sub1_function2() :
    print('main과 같은 패키지의 모듈 sub1 fun2')
