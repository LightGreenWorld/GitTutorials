### sub2.py ###

def sub2_function1() :
    print('main과 같은 패키지의 모듈 sub2 fun1')

def sub2_function2() :
    print('main과 같은 패키지의 모듈 sub2 fun2')
