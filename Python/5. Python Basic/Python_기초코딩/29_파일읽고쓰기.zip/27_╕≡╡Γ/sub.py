### sub.py ###
print('sub.py파일 영역입니다.')

sub_a1 = 100

def sub_function() :
    print('sub_function')

class SubClass1 :
    pass

print(f'sub의 모듈 이름: {__name__}')

if __name__ == '__main__' :
    print('sub 모듈을 실행하였습니다.')
    print('여기는 sub 모듈에 만든 함수나 클래스를 테스트합니다.')