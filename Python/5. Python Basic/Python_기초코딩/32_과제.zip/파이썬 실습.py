# 실습 평가 1) 학생의 정보를 입력 받아 출력하는 프로그램을 작성하시오
# 학생 정보는 이름, 나이, 국어점수, 수학점수, 영어점수로 구성된다.
#
# 출력양식)
# 이름 : 홍길동
# 나이 : 30세
# 국어점수 : 80점
# 수학점수 : 70점
# 영어점수 : 60점
# 총점 : 200점
# 평균 : 70점
# ------------------------------
# 이름 : 최길동
# 나이 : 28세
# 국어점수 : 90점
# 영어점수 : 90점
# 수학점수 : 80점
# 총점 : 200점
# 평균 : 60점
# -----------------------------
# 전체 총점 : 1000점
# 전체 평균 : 80점


import pickle

class Student :

    def __init__(self, name, age, kr, math, en) :
        self.name = name
        self.age = age
        self.kr = kr
        self.math = math
        self.en = en

    def showInfo(self) :
        print(f'이름 : {self.name}')
        print(f'나이 : {self.age}')
        print(f'국어점수 : {self.kr}')
        print(f'수학점수 : {self.math}')
        print(f'영어점수 : {self.en}')

def showMenu() :
    print('-----메뉴-----')
    print('1. 정보입력')
    print('2. 정보출력')
    print('3. 종료')
    a1 = input('메뉴를 선택해주세요 : ')
    return int(a1)

def input_info() :
    print('-------정보 입력-------')
    name = input('이름 : ')
    age = input('나이 : ')
    kr = input('국어점수 : ')
    math = input('수학점수 : ')
    en = input('영어점수 : ')

    student = Student(name, age, kr, math, en)

    with open('student.dat', 'ab') as fp :
        pickle.dump(student, fp)


def showAllStudent() :

    with open('student.dat', 'rb') as fp :

        student_list = []
        try:
            while True :
                a1 = pickle.load(fp)
                student_list.append(a1)
        except :
           pass

    ttl_total = 0

    for obj in student_list :
        print('--------------------')
        print(f'이름 : {obj.name}')
        print(f'나이 : {obj.age}세')
        print(f'국어점수 : {obj.kr}점')
        print(f'수학점수 : {obj.math}점')
        print(f'영어점수 : {obj.en}점')

        ttl = int(obj.kr) + int(obj.math) + int(obj.en)
        avg = ttl // 3

        print(f'총점 : {ttl}점')
        print(f'평균 : {avg}점')

        ttl_total = ttl_total + int(ttl)

    print('------------------------')
    print(f'전체 총점 : {ttl_total}점')
    print(f'전체 평균 : {ttl_total // len(student_list) // 3}점')

if __name__ == '__main__' :
    while True :

        menu = showMenu()
        if menu == 1:
            input_info()
        elif menu == 2:
            showAllStudent()
        elif menu == 3:
            break
        else :
            print('잘못 입력하셨습니다.')

    pass